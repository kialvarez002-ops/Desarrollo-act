//Array para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL ) //

const imagenes = [
  
"https://images.unsplash.com/photo-1756758005190-92941d91b8b2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDh8Ym84alFLVGFFMFl8fGVufDB8fHx8fA%3D%3D",

"https://images.unsplash.com/photo-1757269267274-085b02b0ce8a?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDEwfGJvOGpRS1RhRTBZfHxlbnwwfHx8fHw%3D",
 
"https://images.unsplash.com/photo-1757137910091-1cf071030691?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDExfGJvOGpRS1RhRTBZfHxlbnwwfHx8fHw%3D",

"https://images.unsplash.com/photo-1755745360285-0633c972b0fd?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDE2fGJvOGpRS1RhRTBZfHxlbnwwfHx8fHw%3D",
 
"https://images.unsplash.com/photo-1756806983832-1f056cf24182?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDE1fGJvOGpRS1RhRTBZfHxlbnwwfHx8fHw%3D",
 ];

// Selección de elementos
const boton = document.getElementById("btn-cambiar");
const imageCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

let indice = 0;

boton.addEventListener("click", () => {
  indice++;
  
if (indice >= imagenes.length) {
    indice = 0;
  }

  // Cambiar la imagen
  imageCard.src = imagenes[indice];
  textoCard.textContent = `Imagen 
  ${indice + 1} de ${imagenes.length}`;
  
  });